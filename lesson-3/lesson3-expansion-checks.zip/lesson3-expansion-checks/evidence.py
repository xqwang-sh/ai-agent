import json, re
from datetime import date, datetime
from pathlib import Path
import jsonschema
SCHEMA=json.loads((Path(__file__).parent/'output.schema.json').read_text())
ACTIVE_KINDS={'initial','change','postponed','cancelled'}

def _briefing_pattern():
    distribution = '(?:(?:暨|及|与|和)(?:\\d{4}年?(?:年度)?)?(?:现金分红|分红|利润分配)(?:预案|方案|政策)?)?'
    return '业绩' + distribution + '(?:网上|线上|网络|电话)?说明会'

def _period_pattern():
    labels = {'半年度': 'H1', '中期': 'H1', '半年报': 'H1', '中报': 'H1', '上半年': 'H1', '前三季度': 'Q3', '前三季': 'Q3', '年度': 'FY', '年报': 'FY'}
    for index, numeral in enumerate('一二三四', 1):
        for label in (f'第{numeral}季度', f'{numeral}季度', f'{numeral}季报', f'第{numeral}季', f'{numeral}季', f'第{index}季度', f'{index}季度', f'{index}季报', f'Q{index}'):
            labels[label] = f'Q{index}'
    alternatives = '|'.join(sorted(labels, key=len, reverse=True))
    description = '(?:的)?(?:报告|经营成果|情况|' + _briefing_pattern() + '|业绩)'
    pattern = f'(\\d{{4}})年?({alternatives})((?:(?:{description})?[，,]?(?:以及|暨|及|和|与|、|/|\\+)(?:\\d{{4}}年?)?(?:{alternatives}))*)'
    return (pattern, alternatives, labels)

def _period_value(match):
    _, alternatives, labels = _period_pattern()
    year, first, joined = match.groups()[:3]
    found = [year + '-' + labels[first]]
    joined = re.sub(_briefing_pattern(), '', joined)
    for explicit_year, label in re.findall(f'(?:暨|及|和|与|、|/|\\+)(?:(\\d{{4}})年?)?({alternatives})', joined):
        year = explicit_year or year
        found.append(year + '-' + labels[label])
    return '+'.join(dict.fromkeys(found))

def is_update_title(title):
    return bool(re.search('变更|调整|延期|更正|补充|取消|推迟|延后|暂停|终止|顺延', title or ''))

def source_heading_period(text):
    pattern, _, labels = _period_pattern()
    compact = re.sub('\\s+', '', text or '')

    def declared_in_heading(value):
        activity = '(?:' + _briefing_pattern() + '|(?:上市公司)?集体接待日)'
        matches = re.finditer(pattern + '(?:报告|的|集体|网上|线上|网络|电话|投资者|经营)*' + activity, value)
        periods = [_period_value(match) for match in matches]
        return '+'.join(dict.fromkeys((period for value in periods if value for period in value.split('+')))) or None
    declared = declared_in_heading(compact)
    if declared:
        return declared
    alternatives = '|'.join(sorted((label for label, period in labels.items() if period == 'Q3'), key=len, reverse=True))

    def bind_region(match):
        return match[1] + match[3] if re.search('辖区|地区|上市公司', match[2]) else match[0]
    bound = re.sub(f'(\\d{{4}}年)([^\\d。；;！？!?]{{1,24}}?)({alternatives})', bind_region, compact)
    return declared_in_heading(bound)

def is_quarterly_briefing(title):
    return bool(any((period.endswith('-Q3') for period in (source_heading_period(title) or '').split('+'))) and re.search(_briefing_pattern(), title or ''))

def source_current_period(title, pages):
    """Read a declared current purpose, never an arbitrary historical body mention."""
    declared = source_heading_period(title)
    if declared:
        return declared
    heading = []
    first_text_page = next((page for page in pages if page.strip()), '')
    for line in first_text_page.splitlines()[:24]:
        line = re.sub('\\s+', '', line)
        if re.match('(?:本公司|本行|本公告|重要内容提示|[一二三四五六七八九十]+、)', line):
            break
        heading.append(line)
        candidate = ''.join(heading)
        if len(candidate) > 700:
            break
        if re.search(_briefing_pattern() + '[^。；;！？!?]*?(?:公告|通知)$', candidate):
            declared = source_heading_period(candidate)
            if declared:
                return declared
            break
    pattern, _, _ = _period_pattern()
    name = pattern + '(?:报告|网上|线上|网络|投资者|的)*' + _briefing_pattern()
    current = []
    for sentence in re.split('[。；;！？!?]', re.sub('\\s+', '', '\n'.join(pages))):
        for plan in re.finditer('(?:计划|拟|定|将)(?:于|在)?[^。；;]{0,120}?(?:召开|举行|举办)', sentence):
            if re.search('(?:曾|原|此前|当时|过去|曾经).{0,4}$', sentence[:plan.start()]):
                continue
            meeting = re.search(name, sentence[plan.end():].split('，', 1)[0])
            if meeting:
                current.append(_period_value(meeting))
        for meeting in re.finditer(name, sentence):
            if re.match('(?:现)?(?:计划|拟|定|将)(?:于|在)', sentence[meeting.end():]) and (not re.search('(?:曾|此前|当时|过去|往期)', sentence[:meeting.start()])):
                current.append(_period_value(meeting))
        if re.search('本次(?:业绩|投资者)?说明会|本次活动|届时', sentence):
            purpose = re.search('(?:将(?:在线)?(?:就|针对|介绍|围绕)|公司将针对)(.*)', sentence)
            if purpose and (not re.search('历史|往期|此前|曾', purpose.group(1))):
                financial = pattern + '(?:的)?(?:报告|经营成果|财务|业绩|经营情况|经营状况|生产经营|情况)'
                purpose_text = re.split('对比|比较|对照', purpose.group(1), maxsplit=1)[0]
                current.extend((_period_value(match) for match in re.finditer(financial, purpose_text)))
    return '+'.join(dict.fromkeys((period for value in current if value for period in value.split('+')))) or None

def compact(text: str) -> str:
    return re.sub('\\s+', '', text).replace('：', ':')

def _date_in(value: str, quote: str, source_year: int | None=None) -> bool:
    y, m, d = map(int, value.split('-'))
    q = compact(quote)
    if value in q:
        return True
    context_year, context_month, previous_end = (source_year, None, None)
    for match in re.finditer('(?:(\\d{4})年)?(?:(\\d{1,2})月)?(\\d{1,2})日', q):
        year, month, day = match.groups()
        if month is None and (year is not None or previous_end is None or (not re.fullmatch('[至到~—－–\\-]', q[previous_end:match.start()]))):
            continue
        if year is not None:
            context_year = int(year)
        if month is not None:
            context_month = int(month)
        if context_month == m and int(day) == d and (context_year == y):
            return True
        previous_end = match.end()
    return False

def _time_in(value: str, quote: str) -> bool:
    h, m = map(int, value.split(':'))
    text, phase, previous_end = (compact(quote), None, 0)
    for match in re.finditer('(上午|早上|凌晨|中午|下午|晚上)?(?<!\\d)(\\d{1,2}):(\\d{2})(?!\\d)', text):
        qualifier, hour, minute = match.groups()
        bridge = text[previous_end:match.start()]
        phase = qualifier or (phase if re.fullmatch('[至到~—－–\\-]*', bridge) else None)
        hour, minute = (int(hour), int(minute))
        if phase in {'下午', '晚上'} and 1 <= hour <= 11:
            hour += 12
        if 0 <= hour <= 23 and 0 <= minute <= 59 and ((hour, minute) == (h, m)):
            return True
        previous_end = match.end()
    return False

def source_notice_numbers(header: str) -> list[tuple[str, str]]:
    text = '\n'.join((compact(line) for line in header.splitlines()))
    pattern = '(?:公告编号|公告编码|编号|(?<!证券)(?<!债券)编码)[:：]?(?:第)?(?:临[-－—]?)?(\\d{4})(?:临)?(?:[-－—](?:临)?(\\d+)|[\\[【（(](\\d+)[\\]】）)]|(\\d{3,4}))(?!\\d)'
    return [(year, hyphenated or bracketed or joined) for year, hyphenated, bracketed, joined in re.findall(pattern, text)]

def evidence_text(evidence: dict, pages: list[str]) -> str | None:
    parts = evidence.get('parts') or [evidence]
    for part in parts:
        index = part['page'] - 1
        if not 0 <= index < len(pages) or compact(part['quote']) not in compact(pages[index]):
            return None
    if 'parts' in evidence:
        first, second = parts
        if second['page'] != first['page'] + 1 or not compact(pages[first['page'] - 1]).endswith(compact(first['quote'])) or (not compact(pages[second['page'] - 1]).startswith(compact(second['quote']))):
            return None
    return ''.join((part['quote'] for part in parts))

def _has_grounded_original_relation(data: dict, pages: list[str]) -> bool:
    relation = data.get('relation_evidence')
    number = compact(data.get('related_notice_number') or '').replace('－', '-').replace('—', '-').replace('临', '')
    if not relation or not number or (not 1 <= relation['page'] <= len(pages)):
        return False
    quote = compact(relation['quote'])
    normalized = quote.replace('－', '-').replace('—', '-').replace('临', '')
    number_pattern = re.escape(number) + '(?!\\d)'
    named_notice = re.search('(?:《[^》]*' + _briefing_pattern() + '[^》]*(?:公告|通知)[^》]*》|原' + _briefing_pattern() + '(?:公告|通知))[^。；;]{0,35}(?:公告)?编号[:：]?(?:临)?' + number_pattern, normalized)
    numbered_meeting = re.search('(?:公告)?编号[:：]?(?:临)?' + number_pattern + '[）)]?(?:项下|所述|中的)[^。；;]{0,20}' + _briefing_pattern(), normalized)
    return quote in compact(pages[relation['page'] - 1]) and bool(named_notice or numbered_meeting)

def _meeting_span(quote: str, kind: str) -> str:
    text = compact(quote)
    anchors = list(re.finditer('会议召开日期和时间[:：]?|会议召开时间[:：]?|会议时间[:：]?|说明会(?:召开)?时间(?:为)?[:：]?|召开时间[:：]?|活动时间(?:为)?[:：]?', text))
    if anchors:
        span = text[anchors[-1].end():]
    else:
        planned = re.search('(?:计划于|拟于|定于|将于)([^。；;！？!?]+?)(?:举行|召开|举办|参加)[^。；;！？!?]*' + _briefing_pattern(), text)
        subject_planned = re.search('(?:业绩)?说明会(?:计划|拟|定|将)(?:于|在)([^。；;！？!?]+?)(?:举行|召开|举办)', text)
        shifted = re.search('(?:' + _briefing_pattern() + '|会议)([^。；]*?)(?:延期至|顺延至|变更为|调整为|改为|改至)([^。；]*)', text)
        if shifted and (not re.search('提问|征集|截止|报名', shifted.group(1))):
            span = shifted.group(2)
        else:
            span = subject_planned.group(1) if subject_planned else planned.group(1) if planned else ''
    span = re.split('[。；;！？!?]|提问|征集|截止|报名|发布|披露', span, maxsplit=1)[0]
    if kind in {'change', 'postponed'} and re.search('原计划|原定|原安排', text) and (not re.search('变更为|延期至|顺延至|调整为|改为|改至|会议召开时间', text)):
        return ''
    return span

def validate_evidence(data: dict, pages: list[str], metadata: dict | None=None) -> list[str]:
    errors = ['schema: ' + error.message for error in jsonschema.Draft202012Validator(SCHEMA).iter_errors(data)]
    if errors:
        return errors
    first_text_page = next((page for page in pages if page.strip()), '')
    header = first_text_page
    numbers = source_notice_numbers(header)
    claimed = re.fullmatch('(?:临)?\\s*(\\d{4})\\s*(?:临)?\\s*[-－—]\\s*(?:临)?\\s*(\\d+)', data.get('notice_number') or '')
    if not numbers or not claimed or (int(claimed[1]), int(claimed[2])) != (int(numbers[0][0]), int(numbers[0][1])):
        errors.append('unsupported_notice_number')
    title = (metadata or {}).get('title') or first_text_page.split('重要内容提示', 1)[0]
    current_period = source_current_period(title, pages)
    if data.get('report_period') != current_period:
        errors.append('unsupported_report_period')
    scope_title = compact((metadata or {}).get('title') or first_text_page.split('本公司', 1)[0])
    update_title = is_update_title(scope_title)
    completed = not update_title and re.search('说明会.*召开情况|说明会.*举行情况|说明会.*纪要|说明会.*活动记录', scope_title)
    quarterly_collective = is_quarterly_briefing(scope_title) and '集体' in scope_title
    source_kind = 'completed' if completed else 'initial' if quarterly_collective and (not update_title) else 'collective' if '集体接待' in scope_title else 'other' if re.search('股东大会|股东会|权益分派|分红派息', scope_title) else None
    if source_kind is not None and data['notice_kind'] != source_kind:
        errors.append('source_scope_conflict')
    for key in ['meeting_date', 'previous_meeting_date', 'question_deadline_date']:
        if data[key] is not None:
            try:
                date.fromisoformat(data[key])
            except (ValueError, TypeError):
                errors.append('invalid_date:' + key)
    for key in ['start_time', 'end_time', 'previous_start_time', 'previous_end_time', 'question_deadline_time']:
        if data[key] is not None:
            try:
                datetime.strptime(data[key], '%H:%M')
                if not re.fullmatch('\\d{2}:\\d{2}', data[key]):
                    raise ValueError()
            except (ValueError, TypeError):
                errors.append('invalid_time:' + key)
    if errors:
        return errors
    for key in ['meeting_evidence', 'previous_meeting_evidence', 'deadline_evidence', 'relation_evidence']:
        evidence = data[key]
        if evidence is not None:
            if evidence_text(evidence, pages) is None:
                errors.append('ungrounded_quote:' + key)
    kind = data['notice_kind']
    explicit_years = {int(year) for year in re.findall('(?<!\\d)(\\d{4})年', compact('\n'.join(pages)))}
    source_year = next(iter(explicit_years)) if len(explicit_years) == 1 else None
    if kind not in ACTIVE_KINDS:
        for key in ['meeting_date', 'start_time', 'end_time', 'previous_meeting_date', 'previous_start_time', 'previous_end_time', 'question_deadline_date', 'question_deadline_time', 'participation_url', 'meeting_evidence', 'previous_meeting_evidence', 'deadline_evidence', 'relation_evidence']:
            if data[key] is not None:
                errors.append('non_calendar_field:' + key)
        return errors
    linked_unknown_period = data['report_period'] is None and kind in {'change', 'postponed', 'cancelled'} and _has_grounded_original_relation(data, pages)
    if not data['report_period'] and (not linked_unknown_period) or not data['notice_number']:
        errors.append('missing_event_identity')
    if kind in {'initial', 'change'} and (not data['meeting_date']):
        errors.append('missing_meeting_date')
    for evidence_key, fields in [('meeting_evidence', ['meeting_date', 'start_time', 'end_time']), ('previous_meeting_evidence', ['previous_meeting_date', 'previous_start_time', 'previous_end_time']), ('deadline_evidence', ['question_deadline_date', 'question_deadline_time'])]:
        values = [field for field in fields if data[field] is not None]
        if not values:
            continue
        evidence = data[evidence_key]
        if evidence is None:
            errors.append('missing_evidence:' + evidence_key)
            continue
        literal = evidence_text(evidence, pages) or ''
        quote = _meeting_span(literal, kind) if evidence_key == 'meeting_evidence' else literal
        if evidence_key == 'meeting_evidence' and (not quote):
            errors.append('unproven_meeting_role')
        for field in values:
            supported = _date_in(data[field], quote, source_year) if 'date' in field else _time_in(data[field], quote)
            if not supported:
                errors.append('unsupported_value:' + field)
    for start, end in [('start_time', 'end_time'), ('previous_start_time', 'previous_end_time')]:
        if data[start] and data[end] and (data[start] >= data[end]):
            errors.append('nonpositive_interval:' + start)
    if data['related_notice_number']:
        relation = data['relation_evidence']
        normalize = lambda value: compact(value).replace('临', '').replace('－', '-').replace('—', '-')
        if not relation or normalize(data['related_notice_number']) not in normalize(relation['quote']):
            errors.append('unsupported_notice_relation')
    if data['participation_url']:
        url = data['participation_url']
        if not url.startswith(('http://', 'https://')) or compact(url) not in compact('\n'.join(pages)):
            errors.append('ungrounded_participation_url')
    return errors
