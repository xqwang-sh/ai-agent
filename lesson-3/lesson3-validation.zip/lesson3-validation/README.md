# 独立验证包

在第一次提取后再使用。12份历史公告、35物理页，用于测试，不代表实时查询。原始模型输入只用原PDF或input.jsonl中的全文，不能将teacher-gold.jsonl或评分差异送给提取模型。候选标准由独立读源和交叉核验形成，待任课教师签字确认，先抽查后冻结自己的确认版本。11份用于原模型比较，第12份为2026-10-30新取得的嘉和三季度通知。

将原始输出整理为每行{"id":"公告ID","result":{...}}的actual.jsonl，字段遵循output.schema.json。不要人工改答案后称模型通过。

```sh
python3 -m pip install -r requirements.txt
python3 check_gold.py --actual /path/to/actual.jsonl --report /path/to/report.json
```

12条关键字段和证据全部通过才返回pass，缺记录或重复ID失败。评分程序不调用模型，验证包指纹改变则拒绝评分。program checks不能替代人工看原文。sources.json保存每份公告的原链接、物理页数和PDF指纹。修改候选标准前保留原版本，说明原因并重建指纹。
