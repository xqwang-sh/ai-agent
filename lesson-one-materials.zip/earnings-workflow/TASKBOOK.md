# 第一讲：搭建 earnings-workflow

本目录是起始材料，不含成品应用。先读线上教师讲义，再逐步把主 Prompt 发给自己的编程 Agent。

目标是一个本地网页：Product 展示候选简报，Approaches 解释三个阶段，Evals 对照六行做法。主线为 02 → 04 → 06，后续必须使用本轮已通过的精确前序。

## 已提供的材料

- data/report-pages-60-75.txt：与现场产品完全相同的报告文字窗口，保留物理页边界。不是完整 PDF。
- contracts/workflow.json：案例、阶段、字段、工具、停止和重跑约定。
- prompts/runtime：五份财报任务模板。程序替换 {{CHECKED_INPUT_JSON}} 为本轮已检查前序的真实输入。01 与 02 共用 locate.txt，只改变 thinking。
- history/lesson-one-history.json：六条原始历史输出，供只读回放，不是本轮输入。
- checks/case-reference.json：固定案例评分参考，含案例答案，只给程序检查器，不给财报运行模型。
- checks/history-recomputed.json：历史链按当前规则复算的评分与前序关系。
- checks/synthetic-cases.json：工具与流程的离线检查，不消耗模型额度，结果不能称为真实 Run。
- checks/manifest.json：输入文件指纹。

## 工作边界

主线不下载 PDF、不接同花顺、不生成 PPT、不建立四 Agent 或定时任务。运行模型为 Qwen/Qwen3.5-4B，个人硅基流动 Key 只在网页隐藏输入。OpenCode 的编码模型与本程序授权分开。

先建立空网页，再接历史，再实现 02、04、06，最后加入 01、03、05 对照并验收。程序负责工具、检查、数据依赖和停止；模型执行指定的定位、抄录与工具调用。五项检查通过仍是待人工复核的候选简报。

讲义：https://suibe-ai-agent.netlify.app/handout.html
现有产品：https://suibe-ai-agent.netlify.app/demo#evals
